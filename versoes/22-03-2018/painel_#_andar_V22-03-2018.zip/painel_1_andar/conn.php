<?php
 
//MySQLi Procedural
$conn = mysqli_connect("localhost","root","usbw","painel_codester");
if (!$conn) {
	die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
}
 ?>