<?php
$versao='17.03.22';
$idsoft='TGO';
$minutos=1;
$segundos=$minutos*60;
define('TEMPOREFRESH', $segundos);
$tempo=TEMPOREFRESH/$minutos;
define('NOMEPAINEL', "Painel 1 Andar");//PARA USAR echo NOMEPAINEL
//echo $tempo;
echo "Versão: $idsoft $versao ";
?>
