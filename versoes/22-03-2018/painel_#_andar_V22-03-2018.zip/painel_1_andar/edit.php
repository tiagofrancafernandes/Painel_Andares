<?php
	include('conn.php');
	
	$id=$_GET['id'];
	
	$nomePaciente=$_POST['nomePaciente'];
	$pacienteDiag=$_POST['pacienteDiag'];
	$obsPaciente=$_POST['obsPaciente'];
	$medAssistente=$_POST['medAssistente'];
	$planoPaciente=$_POST['planoPaciente'];
	$riscoPaciente=$_POST['riscoPaciente'];
	$dataEntrada=$_POST['dataEntrada'];
	$quartoPaciente=$_POST['quartoPaciente'];
	
	mysqli_query($conn,"update painel set nomePaciente='$nomePaciente', pacienteDiag='$pacienteDiag', obsPaciente='$obsPaciente', medAssistente='$medAssistente', planoPaciente='$planoPaciente', riscoPaciente='$riscoPaciente', dataEntrada='$dataEntrada', quartoPaciente='$quartoPaciente' where itemID='$id'");
	 header('location:index.php');
	//header('location:controle.php');

?>