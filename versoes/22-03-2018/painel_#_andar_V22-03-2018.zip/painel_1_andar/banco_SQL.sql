-- phpMyAdmin SQL Dump
-- version 4.0.4.2
-- http://www.phpmyadmin.net
--
-- Máquina: localhost
-- Data de Criação: 10-Mar-2018 às 00:26
-- Versão do servidor: 5.6.13
-- versão do PHP: 5.4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de Dados: `painel_codester`
--
CREATE DATABASE IF NOT EXISTS `painel_codester` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `painel_codester`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `painel`
--

CREATE TABLE IF NOT EXISTS `painel` (
  `itemID` int(11) NOT NULL AUTO_INCREMENT,
  `nomePaciente` varchar(30) NOT NULL,
  `pacienteDiag` text NOT NULL,
  `medAssistente` varchar(100) NOT NULL,
  `planoPaciente` varchar(100) NOT NULL,
  `riscoPaciente` text NOT NULL,
  `obsPaciente` text NOT NULL,
  `dataEntrada` varchar(20) NOT NULL,
  `quartoPaciente` varchar(100) NOT NULL,
  PRIMARY KEY (`itemID`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Extraindo dados da tabela `painel`
--

INSERT INTO `painel` (`itemID`, `nomePaciente`, `pacienteDiag`, `medAssistente`, `planoPaciente`, `riscoPaciente`, `obsPaciente`, `dataEntrada`, `quartoPaciente`) VALUES
(12, 'Paciente 2', 'diag 2', 'dr Tiago', 'meu plano', 'riscos', 'observacoes 2', '', '202'),
(13, 'dfdfdfdfdfdfd', 'dfdf', 'aaaaaaaaa', 'aaaaaaaaaaaa', 'aaaaaaaaaa', 'aaaaaaaaaaa', '', '101'),
(14, 'Um novo paciente', 'diagnostico', 'medico assistente', 'plano', 'risco', 'observaÃ§Ã£o', '', '1000'),
(15, '12Nome do Paciente:', '1212DiagnÃ³stico', '12Medico Assistente:', '12Plano:', 'Risco', 'OsbervaÃ§Ã£o', '', '122Quarto:');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
