<!-- Adicionar Novo -->
    <div class="modal fade" id="addnew" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Adicionar Novo</h4>
					<br>
					Os campos com <span style="color:red;">*</span> são obrigatóros.</center>
                </div>
                <div class="container-fluid" style="margin: 1em;">
				<form method="POST" action="addnew.php">
					<div class="row">
						<div style="height:10px;"></div>
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;"><span style="color:red;">*</span>Quarto:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="quartoPaciente" placeholder="Quarto" class="form-control" value="" required>
						</div>
					</div>
					
					<div style="height:10px;"></div>
					
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;"><span style="color:red;">*</span>Nome do Paciente:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="nomePaciente" placeholder="Nome do Paciente" class="form-control" value="" required>
						</div>
					</div>
					
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;">Diagnóstico:</label>
						</div>
						<div class="col-lg-10">
							<textarea type="text" name="pacienteDiag" placeholder="Diagnóstico" class="form-control"></textarea>
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;">Medico Assistente:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="medAssistente" placeholder="Medico Assistente" class="form-control" value="">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;"><span style="color:red;">*</span>Plano:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="planoPaciente" placeholder="Plano" class="form-control" value="" required>
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;">Risco:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="riscoPaciente" placeholder="Risco" class="form-control" value="">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;">Osbervação:</label>
						</div>
						<div class="col-lg-10">
							<textarea type="text" name="obsPaciente" placeholder="Osbervação" class="form-control"></textarea>
						</div>
					</div>
					
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancelar</button>
                    <button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Salvar</a>
				</form>
                </div>
				
            </div>
        </div>
    </div>
