<?php
	include('conn.php');
	$id=$_GET['id'];
	mysqli_query($conn,"delete from painel where itemID='$id'");
	 header('location:index.php');
	//header('location:controle.php');

?>