<!-- Excluir -->
    <div class="modal fade" id="del<?php echo $row['itemID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Excluir</h4></center>
                </div>
                <div class="modal-body">
				<?php
					$del=mysqli_query($conn,"select * from painel where itemID='".$row['itemID']."'");
					$drow=mysqli_fetch_array($del);
				?>
				<div class="container-fluid">
					<h5><center>Tem certeza que quer excluir o Paciente: <strong><?php echo $drow['nomePaciente']; ?></strong>?<br> Isso não tem volta.</center></h5> 
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancelar</button>
                    <a href="delete.php?id=<?php echo $row['itemID']; ?>" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Excluir</a>
                </div>
				
            </div>
        </div>
    </div>
<!-- /.modal -->

<!-- Editar -->
    <div class="modal fade" id="edit<?php echo $row['itemID']; ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <center><h4 class="modal-title" id="myModalLabel">Editar</h4>
						<br>
						Os campos com <span style="color:red;">*</span> são obrigatóros.</center>
                </div>
                <div class="modal-body">
				<?php
					$edit=mysqli_query($conn,"select * from painel where itemID='".$row['itemID']."'");
					$erow=mysqli_fetch_array($edit);
				?>
				<div class="container-fluid">
				<form method="POST" action="edit.php?id=<?php echo $erow['itemID']; ?>">
					<div class="row">
						
							<div style="height:10px;"></div>
							<div class="col-lg-2-label">
								<label style="position:relative; top:7px;"><span style="color:red;">*</span>Quarto:</label>
							</div>
							<div class="col-lg-10">
								<input type="text" name="quartoPaciente" placeholder="Quarto" class="form-control" value="<?php echo $erow['quartoPaciente']; ?>" required>
							</div>
						<div style="height:10px;"></div>
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;"><span style="color:red;"><span style="color:red;">*</span></span>Nome do Paciente:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="nomePaciente" placeholder="Nome do Paciente" class="form-control" value="<?php echo $erow['nomePaciente']; ?>" required>
						</div>
					</div>
					
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;">Diagnóstico:</label>
						</div>
						<div class="col-lg-10">
							<textarea type="text" name="pacienteDiag" placeholder="Diagnóstico" class="form-control"><?php echo $erow['pacienteDiag']; ?></textarea>
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;">Medico Assistente:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="medAssistente" placeholder="Medico Assistente" class="form-control" value="<?php echo $erow['medAssistente']; ?>">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;"><span style="color:red;">*</span>Plano:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="planoPaciente" placeholder="Plano" class="form-control" value="<?php echo $erow['planoPaciente']; ?>" required>
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;">Risco:</label>
						</div>
						<div class="col-lg-10">
							<input type="text" name="riscoPaciente" placeholder="Risco" class="form-control" value="<?php echo $erow['riscoPaciente']; ?>">
						</div>
					</div>
					<div style="height:10px;"></div>
					<div class="row">
						<div class="col-lg-2-label">
							<label style="position:relative; top:7px;">Osbervação:</label>
						</div>
						<div class="col-lg-10">
							<textarea type="text" name="obsPaciente" placeholder="Osbervação" class="form-control"><?php echo $erow['obsPaciente']; ?></textarea>
						</div>
					</div>
					
                </div> 
				</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span> Cancelar</button>
                    <button type="submit" class="btn btn-warning"><span class="glyphicon glyphicon-check"></span> Salvar</button>
                </div>
				</form>
            </div>
        </div>
    </div>
<!-- /.modal -->