<?php
$verID='17.03.27';
$idsoft='TGO';
$minutos=1;
$segundos=$minutos*60;
define('TEMPOREFRESH', $segundos);
$tempo=TEMPOREFRESH/$minutos;
define('NOMEPAINEL', "Painel 1 Andar");//PARA USAR echo NOMEPAINEL
//echo $tempo;
$versao = "Versão: $idsoft $verID ";
echo $versao ;
?>
