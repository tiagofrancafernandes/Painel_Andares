<?php
	include('conn.php');
	include('config.php');
	$seg = 10;
?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo NOMEPAINEL;?></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- <meta http-equiv="refresh" content="0;URL='http://thetudors.example.com/'" /> -->
	<!-- <meta http-equiv="refresh" content="<?php echo TEMPOREFRESH;?>" /> -->
	<meta http-equiv="refresh" content="<?php echo $seg ;?>" /> 	
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="estilo.css" />
</head>
<body>
<div class="container_painel" style="width: 100%; height: auto; margin: 0px auto;">
	<div style="height:10px;"></div>
	<div class="well" style="margin:auto; padding:auto; width:100%;">
	<center>
		<h1><strong><?php echo NOMEPAINEL; ?></strong></h1>
		<?php echo "<h2>$echoDiaSemana | $data </h2>";  ?>
		
	</center>
	
	<span style="font-size:1.3em; color:red"><center><strong>ATENÇÃO: A página se atualizará <u>automaticamente</u> a cada <span style="color:blue;" id="time"><?php echo $seg ;?></span> segundo(s). <br/></strong></center></span>
	<!-- <span style="font-size:15px; color:red"><center><strong>Você pode atualizá-lo manualmente clicando no botão <span style="color:blue;">"Atualizar"</span> abaixo.	</strong></center></span> -->
	<!-- <span style="font-size:15px; color:red"><center><strong>Lembre-se de fazer o backup do banco de dados ao menos 1 vez por semana clicando no no botão <span style="color:blue;">"Fazer Backup do Banco de Dados"</span> em <a href="controle.php" class="btn btn-link"><span class="glyphicon glyphicon-plus"></span> Controle de Pacientes</a>.</strong></center></span> -->
	<!-- <span style="font-size:15px; color:green"><center><strong>Dúvidas, ou problemas diversos relacionados ao painel, ligar no ramal: <span style="color:blue;">4088</span></strong></center></span> -->
	
	<span style="font-size:1.2em; color:green"><center> Esse painel é uma cortesia da TI Local, problemas com o mesmo, acionar <strong>primeiro</strong> pelo ramal <span style="color:blue;">4088</span>.  </center></span>
	<center><?php echo $mensagem_da_TI ;?></center>
	
	
	<center><span class="btn btn-info"><span class="glyphicon glyphicon-fullscreen"></span> Pressione <strong>F11</strong> Para Ativar/Desativar Tela Cheia</span></center>
	<center><span class="btn btn-danger"><span class="glyphicon glyphicon-"></span> Favor, abrir no somente no <strong>Chrome</strong>!</span></center>
	<hr/>
	<!-- <span style="font-size:25px; color:blue"><center><strong><?php echo NOMEPAINEL; ?></strong></center></span>	 -->
		<!-- <span class="pull-left"><a href="#addnew" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Adicionar Novo</a></span> -->
		<span class="pull-left"><a href="javascript:location.reload();" class="btn btn-info"><span class="glyphicon glyphicon-refresh"></span> Atualizar</a></span>
				
		

		
		
		<!-- <span class="pull-left"><a href="bkpdb" class="btn btn-danger" target="_blank"><span class="glyphicon glyphicon-download"></span> Fazer Backup do Banco de Dados</a></span> -->
		
		<span class="pull-right"><a href="controle.php" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Controle de Pacientes</a></span>
        		
		
		<div style="height:50px;"></div>
		<table class="table table-striped table-bordered table-hover">
			<thead style="background: #a9a9b3;">
				<th>Quarto</th>
				<th>Nome do Paciente</th>
				<th>Diagnóstico</th>
				<th>Medico Assistente</th>
				<th>Plano</th>
				<th>Risco</th>
				<th>Observação</th>
				<th>Editar</th>
			</thead>
			<tbody>
			<?php
					
				$query=mysqli_query($conn,"SELECT * 
FROM  `painel` 
ORDER BY  `painel`.`quartoPaciente` ASC ");
				while($row=mysqli_fetch_array($query)){
			?>
			<?php $nome_string = $row['nomePaciente'];
					$letra = explode(" ", $nome_string);
					$iniciais = "";
					for($i=0; $i < count($letra); $i++) {
					$iniciais.= $letra[$i][0];
					}
					//echo $iniciais;
					$iniciais = strtoupper($iniciais);
					//print $iniciais;?>
					<tr >
						<td class="forte vermelho txt_amarelo texto-centro"><?php echo $row['quartoPaciente']; ?></td>
						<td class="forte amarelo texto-centro" style="letter-spacing:2px" title="<?php echo strtoupper($row['nomePaciente']); ?>"><?php echo $iniciais; ?></td>
						<td class="verde"><?php echo strtoupper($row['pacienteDiag']); ?></td>
						<td class="amarelo"><?php echo strtoupper($row['medAssistente']); ?></td>
						<td class="verde texto-centro"><?php echo strtoupper($row['planoPaciente']); ?></td>
						<td class="vermelho txt_amarelo texto-centro"><?php echo strtoupper($row['riscoPaciente']); ?></td>
						<td class="amarelo"><?php echo $row['obsPaciente']; ?></td>
						<td class="vermelho texto-centro">
							<!-- <a href="#edit<?php echo $row['itemID']; ?>" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Editar</a> ||--> 
							<!--<a href="#del<?php echo $row['itemID']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Excluir</a>-->
							<a href="controle.php" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Abrir Controle</a> 
							<?php include('button.php'); ?>
						</td>
					</tr>
					<?php
				}
			
			?>
			</tbody>
		</table>
	</div>
	<?php include('add_modal.php'); ?>
</div>

<?php echo $versao ; ?>

</body>
</html>