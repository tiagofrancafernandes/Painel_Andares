<?php
	include('conn.php');
	include('config.php');
?>
<!DOCTYPE html>
<html>
<head>
	<title>CONTROLE | <?php echo NOMEPAINEL;?></title>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
	
	<!-- INICIO ARQUIVOS PESQUISA -->
	<link rel="stylesheet" href="pesquisa/css/style.css">
	<script  src="pesquisa/js/index.js"></script>
	<!-- FIM ARQUIVOS PESQUISA -->
	
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<!-- <meta http-equiv="refresh" content="0;URL='http://thetudors.example.com/'" /> -->
	<!-- <meta http-equiv="refresh" content="<?php echo TEMPOREFRESH;?>" /> 	 -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" href="estilo.css" />
</head>
<body>
<div class="container_painel" style="width: 100%; height: auto; margin: 0px auto;">
	<div style="height:10px;"></div>
	<div class="well" style="margin:auto; padding:auto; width:100%;">
	<span style="font-size:25px; color:blue"><center>Painel de controle do <strong style="color:red;"><?php echo NOMEPAINEL; ?></strong></center></span>	
	
	<span style="font-size:15px; color:red"><center><strong>Lembre-se de fazer o backup do banco de dados ao menos 1 vez por semana clicando no no botão <span style="color:blue;">"Fazer Backup do Banco de Dados"</span> em <a href="controle.php" class="btn btn-link"><span class="glyphicon glyphicon-plus"></span> Controle de Pacientes</a>.</strong></center></span>
	<span style="font-size:15px; color:green"><center><strong>Dúvidas, ou problemas diversos relacionados ao painel, ligar no ramal: <span style="color:blue;">4088</span></strong></center></span>
	<span style="font-size:15px; color:red"><center> Esse painel é uma cortesia da TI Local, problemas com o mesmo, acionar <strong>primeiro</strong> pelo ramal acima citado.  </center></span>
	<center><span class="btn btn-danger"><span class="glyphicon glyphicon-"></span> Favor, abrir no somente no <strong>Chrome</strong>!</span></center>
	<br/>
	
	
		<span class="pull-left"><a href="#addnew" data-toggle="modal" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Adicionar Novo</a></span>
		<span class="pull-left"><a href="bkpdb" class="btn btn-danger" target="_blank"><span class="glyphicon glyphicon-download"></span> Fazer Backup do Banco de Dados</a></span>
		<span class="pull-left"><a href="javascript:location.reload();" class="btn btn-info"><span class="glyphicon glyphicon-refresh"></span> Atualizar</a></span>
		<span class="pull-right"><a href="index.php" class="btn btn-primary"><span class="glyphicon glyphicon-plus"></span> Ir para o PAINEL</a></span>
		<span class="pull-right"><a href="javascript:location.reload();" class="btn btn-info"><span class="glyphicon glyphicon-refresh"></span> Atualizar</a></span>
		
		<div style="height:50px;"></div>
		
		<div class="form-group pull-right">
			<input id="pesuisaTabela" type="text" class="search form-control" placeholder="Pesquise aqui">
				<span class="contador"></span>
			<span class="sem-resultados " style="display: none;">
				<td colspan="4"><i class="fa fa-warning"></i> Nenhum resultado para a pesquisa</td>
			</span>
			
		</div>
		
		<table class="table table-striped table-bordered table-hover resultados">
			<thead style="background: #a9a9b3;">
				<th>Quarto</th>
				<th>Nome do Paciente</th>
				<th>Diagnóstico</th>
				<th>Medico Assistente</th>
				<th>Plano</th>
				<th>Risco</th>
				<th>Observação</th>
				<th>Editar</th>
			</thead>
			<tbody>
			<?php				
				$query=mysqli_query($conn,"SELECT * 
FROM  `painel` 
ORDER BY  `painel`.`quartoPaciente` ASC ");
				while($row=mysqli_fetch_array($query)){
			?>
					<tr >
						<td><?php echo $row['quartoPaciente']; ?></td>
						<td><?php echo strtoupper($row['nomePaciente']); ?></td>
						<td><?php echo strtoupper($row['pacienteDiag']); ?></td>
						<td><?php echo strtoupper($row['medAssistente']); ?></td>
						<td><?php echo strtoupper($row['planoPaciente']); ?></td>
						<td><?php echo strtoupper($row['riscoPaciente']); ?></td>
						<td><?php echo $row['obsPaciente']; ?></td>
						<td>
							<a href="#edit<?php echo $row['itemID']; ?>" data-toggle="modal" class="btn btn-warning"><span class="glyphicon glyphicon-edit"></span> Editar</a> || 
							<a href="#del<?php echo $row['itemID']; ?>" data-toggle="modal" class="btn btn-danger"><span class="glyphicon glyphicon-trash"></span> Excluir</a>
							<?php include('button.php'); ?>
						</td>
					</tr>
					<?php
				}
			
			?>
			</tbody>
		</table>
	</div>
	<?php include('add_modal.php'); ?>
</div>
</body>
</html>