<?php
	include('conn.php');
	
	$nomePaciente=$_POST['nomePaciente'];
	$pacienteDiag=$_POST['pacienteDiag'];
	$quartoPaciente=$_POST['quartoPaciente'];
	$obsPaciente=$_POST['obsPaciente'];
	$medAssistente=$_POST['medAssistente'];
	$planoPaciente=$_POST['planoPaciente'];
	$riscoPaciente=$_POST['riscoPaciente'];
	$dataEntrada=$_POST['dataEntrada'];
	
	mysqli_query($conn,"insert into painel (nomePaciente, pacienteDiag, quartoPaciente, obsPaciente, medAssistente, planoPaciente, riscoPaciente, dataEntrada) values ('$nomePaciente', '$pacienteDiag', '$quartoPaciente', '$obsPaciente', '$medAssistente', '$planoPaciente', '$riscoPaciente', '$dataEntrada')");
	header('location:index.php');
	//header('location:controle.php');

?>