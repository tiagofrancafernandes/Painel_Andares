<?php
$verID='18.03.27';
$idsoft='TGO';
$minutos=1;
$segundos=$minutos*60;
define('TEMPOREFRESH', $segundos);
$tempo=TEMPOREFRESH/$minutos;
define('NOMEPAINEL', "Painel 1 Andar");//PARA USAR echo NOMEPAINEL
//echo $tempo;
$versao = "Versão: $idsoft $verID ";
//echo $versao ;


	//****MOSTRA RELOGIO
	//setlocale( LC_ALL, 'pt_BR', 'pt_BR.iso-8859-1', 'pt_BR.utf-8', 'portuguese' ); 
	date_default_timezone_set( 'America/Sao_Paulo' );

	//FUNÇÃO DATE() 
	$data = date('d/m/Y H:i ');
	//Mostra Ex: 27/03/2018 17:19:46 
	//echo "<h2>$data</h2>"; 
	
	//****DIAS DA SEMANA
	// Array com os dias da semana
	$diasemana = array('Domingo', 'Segunda-Feira', 'Terça-Feira', 'Quarta-Feira', 'Quinta-Feira', 'Sexta', 'Sábado');

	// Aqui podemos usar a data atual ou qualquer outra data no formato Ano-mês-dia (2014-02-28)
	//$data = date('Y-m-d');

	// Varivel que recebe o dia da semana (0 = Domingo, 1 = Segunda ...)
	$diasemana_numero = date('w', strtotime($data));
	$echoDiaSemana = $diasemana[$diasemana_numero];
	// Exibe o dia da semana com o Array
	//echo $diasemana[$diasemana_numero];
	$mensagem_da_TI = "MENSAGEM DA TI: <a href='index2.php'>Testar versão com cores</a> || <a href='index.php'>Versão Normal</a>
	"



?>
